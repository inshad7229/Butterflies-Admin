import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule,FormsModule } from '@angular/forms';

import { CountriesRoutingModule } from './countries-routing.module';
import { CountriesComponent } from './countries.component';
import { PageHeaderModule } from './../../shared';
import {AdminService} from '../../shared/services/admin/admin.service'

@NgModule({
  imports: [
    CommonModule,
    CountriesRoutingModule,
    PageHeaderModule,
    ReactiveFormsModule,
FormsModule
  ],
  declarations: [CountriesComponent],
  providers:[AdminService]
})
export class CountriesModule { }
