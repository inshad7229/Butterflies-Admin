import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms'
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { routerTransition } from '../../router.animations';
import {AdminService} from '../../shared/services/admin/admin.service'
@Component({
  selector: 'app-countries',
  templateUrl: './countries.component.html',
  styleUrls: ['./countries.component.scss'],
  animations: [routerTransition()]
})
export class CountriesComponent implements OnInit {
  verifiactionForm:FormGroup
  CountyList
  constructor(public router: Router, private fb: FormBuilder,private adminService:AdminService,) {
    this.verifiactionForm = fb.group({
                'countryName': [null, Validators.compose([Validators.required,Validators.maxLength(12)])],
            
        }) }

  ngOnInit() {
        this.adminService.onGetAdmin()
        .subscribe(data=>{
            if(data.response){;
              this.CountyList=data.result
            }else{
                
            }
        })
  }

  getClass(i){
    if (i%2==0) {
     return 'table-success'
    }else{
      return 'table-info'
    }
  }

}
