webpackJsonp(["cities.module"],{

/***/ "../../../../../src/app/layout/cities/cities-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CitiesRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__cities_component__ = __webpack_require__("../../../../../src/app/layout/cities/cities.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var routes = [
    {
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_2__cities_component__["a" /* CitiesComponent */]
    }
];
var CitiesRoutingModule = (function () {
    function CitiesRoutingModule() {
    }
    CitiesRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["d" /* RouterModule */].forChild(routes)],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["d" /* RouterModule */]]
        })
    ], CitiesRoutingModule);
    return CitiesRoutingModule;
}());



/***/ }),

/***/ "../../../../../src/app/layout/cities/cities.component.html":
/***/ (function(module, exports) {

module.exports = "<div [@routerTransition]>\n    <app-page-header [heading]=\"'Cities'\" [icon]=\"'fa-edit'\"></app-page-header>\n    <div class=\"row\">\n        <div class=\"col-lg-12\">\n            <form role=\"form\" [formGroup]=\"verifiactionForm\">\n            \t <div class=\"form-group\">\n                    <label>Country</label>\n                    <select class=\"form-control\"  [formControl]=\"verifiactionForm.controls['country_id']\" [(ngModel)]=\"datamodel.country_id\" >\n                        <option disabled=\"\">-----Choose Country-----</option>\n                        <option *ngFor=\"let country of CountyList\" [value]=\"country.id\">{{country.name}}</option>\n                    </select>\n                     <p  *ngIf=\"verifiactionForm.controls['country_id'].hasError('required') && verifiactionForm.controls['country_id'].touched\">\n                     Country Name is <strong>required</strong>\n                    </p>\n                </div>\n                <div class=\"form-group has-success\">\n                    <label class=\"form-control-label\" for=\"inputSuccess\">City Name</label>\n                    <input type=\"text\" class=\"form-control form-control-success\" id=\"inputSuccess\" [formControl]=\"verifiactionForm.controls['city_name']\" [(ngModel)]=\"datamodel.city_name\">\n                    <p  *ngIf=\"verifiactionForm.controls['city_name'].hasError('required') && verifiactionForm.controls['city_name'].touched\">\n                     City Name is <strong>required</strong>\n                    </p>\n                    <p  *ngIf=\"verifiactionForm.controls['city_name'].hasError('pattern')\">\n                               Please enter valid City Name !!\n                    </p>\n                    <p  *ngIf=\"verifiactionForm.controls['city_name'].hasError('maxlength')\">\n                               max length is 100\n                    </p>\n\t\t\t\t</div>\n\t\t            <button type=\"submit\" class=\"btn btn-secondary\" \n                    [disabled]=\"!verifiactionForm.valid\" (click)=\"onSubmit()\">Submit</button>\n\t\t            \n                    <button type=\"reset\" class=\"btn btn-secondary\" (click)=\"onReset()\">Reset Button</button>\n            </form>\n        </div>\n    </div>\n    <div class=\"row\">\n    \t<div class=\"contn-class\">\n                <div class=\"card-header\">Cities List</div>\n                <table class=\"card-body table\" matSort (matSortChange)=\"sortData($event)\" *ngIf=\"sortedData\">\n                    <thead>\n                    <tr>\n                        <th>#</th>\n                        <th  mat-sort-header=\"country_name\">Country Name</th>\n                        <th  mat-sort-header=\"city_name\">City Name</th>\n                        <th  mat-sort-header=\"status\">Status</th>\n                        <th>Action</th>\n                    </tr>\n                    </thead>\n                    <tbody>\n                    <tr *ngFor=\"let city of sortedData ;let i=index\" class=\"{{getClass(i)}}\">\n                        <th scope=\"row\">{{i+1}}</th>\n                        <td >{{city.Country.name}}</td>\n                        <td >{{city.city_name}}</td>\n                        <td >\n                                 <span class=\"cus-switch\">\n                                    <label class=\"switch m-b-0\">\n                                        <input type=\"checkbox\" [(ngModel)]=\"city.status\" [ngModelOptions]=\"{standalone: true}\" (change)=\"onChange(city)\">\n                                        <span class=\"slider round\"></span>\n                                    </label>\n                                </span>\n                        </td>\n                        <td >\n                            <a  href=\"javascript:void(0)\" (click)=\"onEdit(city)\" class=\"fa fa-pencil-square-o fa-lg user-button\" ></a>\n                            <a  href=\"javascript:void(0)\" (click)=\"opendelete(city)\" class=\"fa fa-trash fa-lg user-button\" ></a>\n                        </td>\n                    </tr>\n                    </tbody>\n                </table>\n            </div>\n                <mat-paginator *ngIf=\"CountyList\" #pager [length]=\"CityList.length\"\n                                  [pageSize]=\"pageSize\"\n                                  [pageSizeOptions]=\"[5, 10, 25, 100]\" (page)=\"pageoption($event)\">\n                </mat-paginator>\n    </div>\n    <!-- /.row -->\n</div>\n"

/***/ }),

/***/ "../../../../../src/app/layout/cities/cities.component.scss":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../../css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".contn-class {\n  float: left;\n  width: 100%;\n  padding: 20px 15px; }\n", ""]);

// exports


/*** EXPORTS FROM exports-loader ***/
module.exports = module.exports.toString();

/***/ }),

/***/ "../../../../../src/app/layout/cities/cities.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CitiesComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return CityConfirmation; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_forms__ = __webpack_require__("../../../forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_ng2_toastr__ = __webpack_require__("../../../../ng2-toastr/ng2-toastr.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_ng2_toastr___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_ng2_toastr__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_rxjs_observable_forkJoin__ = __webpack_require__("../../../../rxjs/_esm5/observable/forkJoin.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__angular_material__ = __webpack_require__("../../../material/esm5/material.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__router_animations__ = __webpack_require__("../../../../../src/app/router.animations.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__shared_services_admin_admin_service__ = __webpack_require__("../../../../../src/app/shared/services/admin/admin.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};








var CitiesComponent = (function () {
    function CitiesComponent(router, fb, adminService, dialog, vcr, toastr) {
        this.router = router;
        this.fb = fb;
        this.adminService = adminService;
        this.dialog = dialog;
        this.toastr = toastr;
        this.users = [];
        this.listIndex = 1;
        this.listSize = 10;
        this.pageIndex = 0;
        this.pageSize = 1;
        this.pageSizeOptions = [5, 10, 25, 100];
        this.editStatus = false;
        this.toastr.setRootViewContainerRef(vcr);
        this.datamodel = {};
        this.verifiactionForm = fb.group({
            'city_name': [null, __WEBPACK_IMPORTED_MODULE_0__angular_forms__["j" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_0__angular_forms__["j" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_0__angular_forms__["j" /* Validators */].maxLength(100)])],
            'country_id': [null, __WEBPACK_IMPORTED_MODULE_0__angular_forms__["j" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_0__angular_forms__["j" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_0__angular_forms__["j" /* Validators */].maxLength(100)])],
        });
    }
    CitiesComponent.prototype.setPageSizeOptions = function (setPageSizeOptionsInput) {
        this.pageSizeOptions = setPageSizeOptionsInput.split(',').map(function (str) { return +str; });
    };
    CitiesComponent.prototype.ngOnInit = function () {
        this.onGetList();
    };
    CitiesComponent.prototype.onGetList = function () {
        var _this = this;
        this.users = [];
        this.adminService.CountriesList();
        Object(__WEBPACK_IMPORTED_MODULE_4_rxjs_observable_forkJoin__["a" /* forkJoin */])([this.adminService.CountriesList(), this.adminService.CityList()])
            .subscribe(function (data) {
            console.log(data);
            if (data[0].response) {
                ;
                _this.CountyList = data[0].result.filter(function (arg) { return arg.status == 1; });
                _this.CityList = data[1].result;
                _this.toastr.success('Country List and City List', 'Success', { toastLife: 2000, showCloseButton: true });
                //this.sortedData=data.result 
                if (_this.CityList.length > 5) {
                    _this.pageSize = 5;
                }
                else {
                    _this.pageSize = _this.CityList.length;
                }
                for (var i = _this.pageIndex * _this.pageSize; i < (_this.pageIndex * _this.pageSize + _this.pageSize); i++) {
                    _this.users.push(_this.CityList[i]);
                    _this.sortedData = _this.users.slice();
                }
            }
            else {
                _this.toastr.error(data[0].message, 'Error', { toastLife: 2000, showCloseButton: true });
            }
        });
    };
    CitiesComponent.prototype.getClass = function (i) {
        if (i % 2 == 0) {
            return 'table-success';
        }
        else {
            return 'table-info';
        }
    };
    CitiesComponent.prototype.sortData = function (sort) {
        var data = this.users.slice();
        if (!sort.active || sort.direction == '') {
            this.sortedData = data;
            return;
        }
        this.sortedData = data.sort(function (a, b) {
            var isAsc = sort.direction == 'asc';
            switch (sort.active) {
                case 'country_name': return compare(a.Country.name.trim(), b.Country.name.trim(), isAsc);
                case 'city_name': return compare(a.city_name, b.city_name, isAsc);
                case 'status': return compare(a.status, b.status, isAsc);
                default: return 0;
            }
        });
    };
    CitiesComponent.prototype.pageoption = function (event) {
        this.pageSize = event.pageSize;
        this.pageIndex = event.pageIndex;
        this.users = [];
        for (var i = this.pageIndex * this.pageSize; i < (this.pageIndex * this.pageSize + this.pageSize); i++) {
            if (i == this.CityList.length) {
                break;
            }
            else {
                this.users.push(this.CityList[i]);
                this.sortedData = this.users.slice();
            }
        }
    };
    CitiesComponent.prototype.onEdit = function (country) {
        this.datamodel = Object.assign({}, country);
        console.log(this.datamodel);
    };
    CitiesComponent.prototype.onReset = function () {
        this.datamodel = {};
    };
    CitiesComponent.prototype.onSubmit = function () {
        var _this = this;
        if (this.datamodel.id) {
            this.adminService.oneditCity(this.datamodel)
                .subscribe(function (data) {
                if (data.response) {
                    ;
                    var index = _this.CityList.map(function (img) { return img.id; }).indexOf(_this.datamodel.id);
                    _this.toastr.success('City Edited', 'Success', { toastLife: 2000, showCloseButton: true });
                    _this.onGetList();
                    _this.datamodel.country_id = null;
                    _this.verifiactionForm.reset();
                }
                else {
                    _this.toastr.error(data.message, 'Error', { toastLife: 2000, showCloseButton: true });
                }
            });
        }
        else {
            this.adminService.onAddCity(this.datamodel)
                .subscribe(function (data) {
                if (data.response) {
                    ;
                    _this.onGetList();
                    _this.datamodel.country_id = null;
                    _this.verifiactionForm.reset();
                    _this.toastr.success('City Added Successfully', 'Success', { toastLife: 2000, showCloseButton: true });
                }
                else {
                    _this.toastr.error(data.message, 'Error', { toastLife: 2000, showCloseButton: true });
                }
            });
        }
    };
    CitiesComponent.prototype.onChange = function (data) {
        var _this = this;
        this.adminService.oneditCityStatus(data)
            .subscribe(function (data) {
            if (data.response) {
                ;
                // this.onGetList()
                _this.toastr.success('City updated Successfully', 'Success', { toastLife: 2000, showCloseButton: true });
            }
            else {
                _this.toastr.error(data.message, 'Error', { toastLife: 2000, showCloseButton: true });
            }
        });
    };
    //this.customersList.map(function (img) { return img.customer_id; }).indexOf(this.appointMents[i].customer_id)==-1
    CitiesComponent.prototype.onDelete = function (id) {
        var _this = this;
        this.adminService.oneDeleteCity(id)
            .subscribe(function (data) {
            if (data.response) {
                ;
                _this.CityList = _this.CityList.filter(function (arg) { return arg.id != id; });
                _this.toastr.success('City deleted', 'Success', { toastLife: 2000, showCloseButton: true });
                _this.users = [];
                if (_this.CityList.length > 5) {
                    _this.pageSize = 5;
                }
                else {
                    _this.pageSize = _this.CityList.length;
                }
                for (var i = _this.pageIndex * _this.pageSize; i < (_this.pageIndex * _this.pageSize + _this.pageSize); i++) {
                    _this.users.push(_this.CityList[i]);
                    _this.sortedData = _this.users.slice();
                }
            }
            else {
            }
        });
    };
    CitiesComponent.prototype.opendelete = function (data) {
        var _this = this;
        var dialogRef = this.dialog.open(CityConfirmation, {
            width: '400px',
        });
        dialogRef.afterClosed().subscribe(function (result) {
            if (result) {
                _this.onDelete(data.id);
            }
        });
    };
    CitiesComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_1__angular_core__["Component"])({
            selector: 'app-cities',
            template: __webpack_require__("../../../../../src/app/layout/cities/cities.component.html"),
            styles: [__webpack_require__("../../../../../src/app/layout/cities/cities.component.scss")],
            animations: [Object(__WEBPACK_IMPORTED_MODULE_6__router_animations__["a" /* routerTransition */])()]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_2__angular_router__["c" /* Router */], __WEBPACK_IMPORTED_MODULE_0__angular_forms__["b" /* FormBuilder */], __WEBPACK_IMPORTED_MODULE_7__shared_services_admin_admin_service__["a" /* AdminService */], __WEBPACK_IMPORTED_MODULE_5__angular_material__["b" /* MatDialog */], __WEBPACK_IMPORTED_MODULE_1__angular_core__["ViewContainerRef"],
            __WEBPACK_IMPORTED_MODULE_3_ng2_toastr__["ToastsManager"]])
    ], CitiesComponent);
    return CitiesComponent;
}());

function compare(a, b, isAsc) {
    if (a && isNaN(a)) {
        return (a.toLowerCase() < b.toLowerCase() ? -1 : 1) * (isAsc ? 1 : -1);
    }
    else {
        return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
    }
}
var CityConfirmation = (function () {
    function CityConfirmation(dialogRef, data, router, adminService, dialog) {
        this.dialogRef = dialogRef;
        this.data = data;
        this.router = router;
        this.adminService = adminService;
        this.dialog = dialog;
    }
    CityConfirmation.prototype.onYesClick = function () {
        this.dialogRef.close('yes');
        // this.homePage.onDelete(this.data.admin)
    };
    CityConfirmation.prototype.onNoClick = function () {
        this.dialogRef.close();
    };
    CityConfirmation = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_1__angular_core__["Component"])({
            selector: 'cities-confirmation-dialog',
            template: __webpack_require__("../../../../../src/app/layout/cities/confirmation.html"),
            animations: [Object(__WEBPACK_IMPORTED_MODULE_6__router_animations__["a" /* routerTransition */])()]
        }),
        __param(1, Object(__WEBPACK_IMPORTED_MODULE_1__angular_core__["Inject"])(__WEBPACK_IMPORTED_MODULE_5__angular_material__["a" /* MAT_DIALOG_DATA */])),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_5__angular_material__["d" /* MatDialogRef */], Object, __WEBPACK_IMPORTED_MODULE_2__angular_router__["c" /* Router */],
            __WEBPACK_IMPORTED_MODULE_7__shared_services_admin_admin_service__["a" /* AdminService */],
            __WEBPACK_IMPORTED_MODULE_5__angular_material__["b" /* MatDialog */]])
    ], CityConfirmation);
    return CityConfirmation;
}());



/***/ }),

/***/ "../../../../../src/app/layout/cities/cities.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CitiesModule", function() { return CitiesModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("../../../common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_forms__ = __webpack_require__("../../../forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__angular_material_sort__ = __webpack_require__("../../../material/esm5/sort.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_ngx_pagination__ = __webpack_require__("../../../../ngx-pagination/dist/ngx-pagination.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__angular_material__ = __webpack_require__("../../../material/esm5/material.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_ng2_toastr_ng2_toastr__ = __webpack_require__("../../../../ng2-toastr/ng2-toastr.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_ng2_toastr_ng2_toastr___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_6_ng2_toastr_ng2_toastr__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__shared__ = __webpack_require__("../../../../../src/app/shared/index.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__shared_services_admin_admin_service__ = __webpack_require__("../../../../../src/app/shared/services/admin/admin.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__cities_routing_module__ = __webpack_require__("../../../../../src/app/layout/cities/cities-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__cities_component__ = __webpack_require__("../../../../../src/app/layout/cities/cities.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};











var CitiesModule = (function () {
    function CitiesModule() {
    }
    CitiesModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_9__cities_routing_module__["a" /* CitiesRoutingModule */],
                __WEBPACK_IMPORTED_MODULE_7__shared__["b" /* PageHeaderModule */],
                __WEBPACK_IMPORTED_MODULE_2__angular_forms__["i" /* ReactiveFormsModule */],
                __WEBPACK_IMPORTED_MODULE_2__angular_forms__["d" /* FormsModule */],
                __WEBPACK_IMPORTED_MODULE_3__angular_material_sort__["a" /* MatSortModule */],
                __WEBPACK_IMPORTED_MODULE_4_ngx_pagination__["a" /* NgxPaginationModule */],
                __WEBPACK_IMPORTED_MODULE_5__angular_material__["f" /* MatPaginatorModule */],
                __WEBPACK_IMPORTED_MODULE_5__angular_material__["c" /* MatDialogModule */],
                __WEBPACK_IMPORTED_MODULE_6_ng2_toastr_ng2_toastr__["ToastModule"].forRoot(),
            ],
            declarations: [__WEBPACK_IMPORTED_MODULE_10__cities_component__["a" /* CitiesComponent */], __WEBPACK_IMPORTED_MODULE_10__cities_component__["b" /* CityConfirmation */]],
            providers: [__WEBPACK_IMPORTED_MODULE_8__shared_services_admin_admin_service__["a" /* AdminService */]],
            entryComponents: [__WEBPACK_IMPORTED_MODULE_10__cities_component__["b" /* CityConfirmation */]]
        })
    ], CitiesModule);
    return CitiesModule;
}());



/***/ }),

/***/ "../../../../../src/app/layout/cities/confirmation.html":
/***/ (function(module, exports) {

module.exports = "<div class=\"modal-header\">\r\n\t<h4 class=\"modal-title\" >Hey!! <span class=\"pull-right\"><a (click)=\"onNoClick()\"><i class=\"fa fa-times\"></i></a></span> </h4>\r\n</div>\r\n<div class=\"modal-body\">\r\n\t<div >\r\n\t\t<p >Are you sure you want to delete this City? </p>\r\n\t</div>\r\n\t<div  >\r\n\t\t<button class=\"btn btn-round btn-mat btn-disabled btn-success\" style=\"width: 48%\" (click)=\"onYesClick()\">Yes</button>\r\n\t\t<button class=\"btn btn-round btn-mat btn-disabled btn-danger\" style=\"width: 48%\" (click)=\"onNoClick()\">No Thanks</button>\r\n\t</div>\r\n</div>"

/***/ })

});
//# sourceMappingURL=cities.module.chunk.js.map