webpackJsonp(["user-list.module"],{

/***/ "../../../../../src/app/layout/user-list/confirmation.html":
/***/ (function(module, exports) {

module.exports = "<div class=\"modal-header\">\r\n\t<h4 class=\"modal-title\" >Hey!! <span class=\"pull-right\"><a (click)=\"onNoClick()\"><i class=\"fa fa-times\"></i></a></span> </h4>\r\n</div>\r\n<div class=\"modal-body\">\r\n\t<div >\r\n\t\t<p >Are you sure you want to delete this User? </p>\r\n\t</div>\r\n\t<div  >\r\n\t\t<button class=\"btn btn-round btn-mat btn-disabled btn-success\" style=\"width: 48%\" (click)=\"onYesClick()\">Yes</button>\r\n\t\t<button class=\"btn btn-round btn-mat btn-disabled btn-danger\" style=\"width: 48%\" (click)=\"onNoClick()\">No Thanks</button>\r\n\t</div>\r\n</div>"

/***/ }),

/***/ "../../../../../src/app/layout/user-list/user-list-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return UserListRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__user_list_component__ = __webpack_require__("../../../../../src/app/layout/user-list/user-list.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var routes = [{
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_2__user_list_component__["b" /* UserListComponent */]
    }];
var UserListRoutingModule = (function () {
    function UserListRoutingModule() {
    }
    UserListRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["d" /* RouterModule */].forChild(routes)],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["d" /* RouterModule */]]
        })
    ], UserListRoutingModule);
    return UserListRoutingModule;
}());



/***/ }),

/***/ "../../../../../src/app/layout/user-list/user-list.component.html":
/***/ (function(module, exports) {

module.exports = "<div [@routerTransition]>\n    <app-page-header [heading]=\"'Users'\" [icon]=\"'fa-edit'\"></app-page-header>\n    <div class=\"row\">\n    \t<div class=\"contn-class\">\n                      <nav class=\"navbar navbar-expand-lg navbar-light bg-light\">\n                    <div class=\"collapse navbar-collapse\">\n                        <div class=\"mr-auto\">\n                            <span>Users List\n                            </span>\n                        </div>\n                        <form class=\"form-inline my-2 my-lg-0 right\">\n                            <div class=\"form-inline my-2 my-lg-0 right\">\n                                <input (input)=\"searchUser(pager)\" [(ngModel)]=\"searchInput\" name='searchInput' class=\"form-control mr-sm-2\" type=\"text\" placeholder=\"Search\" aria-label=\"Search\">\n                                <!-- <button class=\"btn btn-outline-success my-2 my-sm-0\" >Search</button> -->\n                            </div>\n                        </form>\n                    </div>\n                </nav>\n                <table class=\"card-body table\" matSort (matSortChange)=\"sortData($event)\" *ngIf=\"sortedData\">\n                    <thead>\n                    <tr>\n                        <th>#</th>\n                        <th mat-sort-header=\"name\">Name</th>\n                        <th mat-sort-header=\"email\">Email</th>\n                        <th mat-sort-header=\"contact\">Contact</th>\n                        <th mat-sort-header=\"register\">Register For</th>\n                        <th mat-sort-header=\"gender\">Gender</th>\n                        <th mat-sort-header=\"vegetarian\">Vegetarian</th>\n                        <th mat-sort-header=\"status\">Status</th>\n                        <th>Action</th>\n                    </tr>\n                    </thead>\n                    <tbody>\n                    <tr *ngFor=\"let user of sortedData ;let i=index\">\n                        <th scope=\"row\">{{i+1}}</th>\n                        <td >{{user.name}}</td>\n                        <td >{{user.email}}</td>\n                        <td >{{user.contact_no}}</td>\n                        <td >{{user.register_for}}</td>\n                        <td >{{user.gender}}</td>\n                        <td >{{user.vegetarian}}</td>\n                        <td >\n                                 <span class=\"cus-switch\">\n                                    <label class=\"switch m-b-0\">\n                                        <input type=\"checkbox\" [(ngModel)]=\"user.status\" \n                                        [ngModelOptions]=\"{standalone: true}\" (change)=\"onChange(user)\">\n                                        <span class=\"slider round\"></span>\n                                    </label>\n                                </span>\n                        </td>\n                        <td >\n                            <a  href=\"javascript:void(0)\" [routerLink]=\"['/userDetail/',user.id]\" class=\"fa fa-eye\" title=\"View Detail\" ></a>\n                            <a  href=\"javascript:void(0)\" (click)=\"opendelete(user)\" class=\"fa fa-trash fa-lg user-button\" ></a>\n                        </td>\n                    </tr>\n                    </tbody>\n                </table>\n            </div>\n                <mat-paginator  #pager   [length]=\"usersDataBackup.length\"\n                                  [pageSize]=\"pageSize\"\n                                  [pageSizeOptions]=\"[5, 10, 25, 100]\" (page)=\"pageoption($event)\">\n                </mat-paginator>\n    </div>\n    <!-- /.row -->\n</div>\n"

/***/ }),

/***/ "../../../../../src/app/layout/user-list/user-list.component.scss":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../../css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".contn-class {\n  float: left;\n  width: 100%;\n  padding: 20px 15px; }\n", ""]);

// exports


/*** EXPORTS FROM exports-loader ***/
module.exports = module.exports.toString();

/***/ }),

/***/ "../../../../../src/app/layout/user-list/user-list.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return UserListComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return UniversityConfirmation; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_forms__ = __webpack_require__("../../../forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_ng2_toastr__ = __webpack_require__("../../../../ng2-toastr/ng2-toastr.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_ng2_toastr___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_ng2_toastr__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__angular_material__ = __webpack_require__("../../../material/esm5/material.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__router_animations__ = __webpack_require__("../../../../../src/app/router.animations.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__shared_services_admin_admin_service__ = __webpack_require__("../../../../../src/app/shared/services/admin/admin.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};







var UserListComponent = (function () {
    function UserListComponent(router, fb, adminService, dialog, vcr, toastr) {
        this.router = router;
        this.fb = fb;
        this.adminService = adminService;
        this.dialog = dialog;
        this.toastr = toastr;
        this.users = [];
        this.listIndex = 1;
        this.listSize = 10;
        this.pageIndex = 0;
        this.pageSize = 1;
        this.pageSizeOptions = [5, 10, 25, 100];
        this.editStatus = false;
        this.toastr.setRootViewContainerRef(vcr);
        this.datamodel = {};
        this.verifiactionForm = fb.group({
            'university_name': [null, __WEBPACK_IMPORTED_MODULE_0__angular_forms__["j" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_0__angular_forms__["j" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_0__angular_forms__["j" /* Validators */].maxLength(100)])],
            'country_id': [null, __WEBPACK_IMPORTED_MODULE_0__angular_forms__["j" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_0__angular_forms__["j" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_0__angular_forms__["j" /* Validators */].maxLength(100)])],
        });
    }
    UserListComponent.prototype.setPageSizeOptions = function (setPageSizeOptionsInput) {
        this.pageSizeOptions = setPageSizeOptionsInput.split(',').map(function (str) { return +str; });
    };
    UserListComponent.prototype.ngOnInit = function () {
        this.usersList();
    };
    UserListComponent.prototype.usersList = function () {
        var _this = this;
        this.adminService.usersList().subscribe(function (data) {
            console.log(data);
            if (data.response == true) {
                _this.AllUsersList = data.result;
                _this.usersDataBackup = data.result;
                if (_this.AllUsersList.length > 5) {
                    _this.pageSize = 5;
                }
                else {
                    _this.pageSize = _this.AllUsersList.length;
                }
                for (var i = _this.pageIndex * _this.pageSize; i < (_this.pageIndex * _this.pageSize + _this.pageSize); i++) {
                    _this.users.push(_this.AllUsersList[i]);
                    _this.sortedData = _this.users.slice();
                }
            }
        });
    };
    UserListComponent.prototype.searchUser = function (pager) {
        var _this = this;
        pager.pageIndex = 0;
        this.usersDataBackup = [];
        this.usersDataBackup = this.AllUsersList.filter(function (it) {
            var b = it.name + it.email + it.email + it.contact_no + it.register_for + it.gemder + it.vegetarian;
            return b.toLowerCase().includes(_this.searchInput.toLowerCase());
        });
        this.pageIndex = 0;
        this.pageSize = 10;
        this.users = [];
        for (var i = this.pageIndex * this.pageSize; i < (this.pageIndex * this.pageSize + this.pageSize); i++) {
            if (i == this.usersDataBackup.length) {
                break;
            }
            else {
                this.users.push(this.usersDataBackup[i]);
                this.sortedData = this.users.slice();
            }
            if (this.usersDataBackup.length - 1 < i + 1) {
                break;
            }
        }
    };
    // onGetList(){
    //   this.users=[]
    //   this.adminService.CountriesList()
    //    forkJoin([this.adminService.CountriesList(), this.adminService.UniversityList()])
    //       .subscribe(data=>{
    //           if(data[0].response && data[1].response){;
    //             this.CountyList=data[0].result.filter(arg=>arg.status == true)
    //             this.UniversityList=data[1].result
    //             this.toastr.success('University List and Countries list ' ,'Success',{toastLife: 2000, showCloseButton: true});
    //             //this.sortedData=data.result 
    //            if (this.UniversityList.length>5){
    //                 this.pageSize=5
    //               }else{
    //                 this.pageSize=this.UniversityList.length  
    //               }
    //               for (var i = this.pageIndex*this.pageSize; i<(this.pageIndex*this.pageSize+this.pageSize); i++) {
    //                this.users.push(this.UniversityList[i])
    //                this.sortedData = this.users.slice();
    //               }
    //           }else if(data[0].response && !data[1].response){
    //              this.CountyList=data[0].result.filter(arg=>arg.status == true)
    //             this.toastr.success('University List' ,'Success',{toastLife: 2000, showCloseButton: true});
    //           }else{
    //             this.toastr.error(data[0].message+',and '+data[1].message ,'Error',{toastLife: 2000, showCloseButton: true});    
    //           }
    //       })
    // }
    UserListComponent.prototype.getClass = function (i) {
        if (i % 2 == 0) {
            return 'table-success';
        }
        else {
            return 'table-info';
        }
    };
    UserListComponent.prototype.sortData = function (sort) {
        var data = this.users.slice();
        if (!sort.active || sort.direction == '') {
            this.sortedData = data;
            return;
        }
        this.sortedData = data.sort(function (a, b) {
            var isAsc = sort.direction == 'asc';
            switch (sort.active) {
                case 'name': return compare(a.name.trim(), b.name.trim(), isAsc);
                case 'email': return compare(a.email, b.email, isAsc);
                case 'contact': return compare(a.contact_no, b.contact_no, isAsc);
                case 'register': return compare(a.register_for.trim(), b.register_for.trim(), isAsc);
                case 'gender': return compare(a.gender.trim(), b.gender.trim(), isAsc);
                case 'vegetarian': return compare(a.vegetarian, b.vegetarian, isAsc);
                case 'status': return compare(a.status, b.status, isAsc);
                default: return 0;
            }
        });
    };
    UserListComponent.prototype.pageoption = function (event) {
        this.pageSize = event.pageSize;
        this.pageIndex = event.pageIndex;
        this.users = [];
        for (var i = this.pageIndex * this.pageSize; i < (this.pageIndex * this.pageSize + this.pageSize); i++) {
            if (i == this.AllUsersList.length) {
                break;
            }
            else {
                this.users.push(this.AllUsersList[i]);
                this.sortedData = this.users.slice();
            }
        }
    };
    UserListComponent.prototype.onEdit = function (country) {
        this.datamodel = Object.assign({}, country);
        console.log(this.datamodel);
    };
    UserListComponent.prototype.onReset = function () {
        this.datamodel = {};
    };
    // onSubmit(){
    //   if (this.datamodel.id) {
    //       this.adminService.oneditUniversity(this.datamodel)
    //         .subscribe(data=>{
    //             if(data.response){;
    //               let index=this.UniversityList.map(function (img) { return img.id; }).indexOf(this.datamodel.id)
    //               this.toastr.success('University Edited' ,'Success',{toastLife: 2000, showCloseButton: true});
    //               this.onGetList()
    //               this.datamodel.country_id=null
    //               this.verifiactionForm.reset();
    //             }else{
    //               this.toastr.error(data.message ,'Error',{toastLife: 2000, showCloseButton: true});  
    //             }
    //         })
    //   }else{
    //       this.adminService.onAddUniversity(this.datamodel)
    //         .subscribe(data=>{
    //             if(data.response){;
    //              this.onGetList()
    //              this.datamodel.country_id=null
    //              this.verifiactionForm.reset();
    //               this.toastr.success('University Added Successfully' ,'Success',{toastLife: 2000, showCloseButton: true});
    //             }else{
    //                this.toastr.error(data.message ,'Error',{toastLife: 2000, showCloseButton: true}); 
    //             }
    //         })
    //   }
    // }
    UserListComponent.prototype.onChange = function (data) {
        var _this = this;
        this.adminService.userStatusUpdateAdmin(data)
            .subscribe(function (data) {
            if (data.response) {
                ;
                _this.toastr.success('User Status Updated Successfully', 'Success', { toastLife: 2000, showCloseButton: true });
            }
            else {
                _this.toastr.error(data.message, 'Error', { toastLife: 2000, showCloseButton: true });
            }
        });
    };
    UserListComponent.prototype.onDelete = function (id) {
        var _this = this;
        this.adminService.userDeleteAdmin(id)
            .subscribe(function (data) {
            if (data.response) {
                _this.AllUsersList = _this.AllUsersList.filter(function (arg) { return arg.id != id; });
                _this.toastr.success('User deleted', 'Success', { toastLife: 2000, showCloseButton: true });
                if (_this.AllUsersList.length > 5) {
                    _this.pageSize = 5;
                }
                else {
                    _this.pageSize = _this.AllUsersList.length;
                }
            }
        });
    };
    UserListComponent.prototype.opendelete = function (data) {
        var _this = this;
        var dialogRef = this.dialog.open(UniversityConfirmation, {
            width: '400px',
        });
        dialogRef.afterClosed().subscribe(function (result) {
            if (result) {
                _this.onDelete(data.id);
            }
        });
    };
    UserListComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_1__angular_core__["Component"])({
            selector: 'app-user-list',
            template: __webpack_require__("../../../../../src/app/layout/user-list/user-list.component.html"),
            styles: [__webpack_require__("../../../../../src/app/layout/user-list/user-list.component.scss")],
            animations: [Object(__WEBPACK_IMPORTED_MODULE_5__router_animations__["a" /* routerTransition */])()]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_2__angular_router__["c" /* Router */], __WEBPACK_IMPORTED_MODULE_0__angular_forms__["b" /* FormBuilder */], __WEBPACK_IMPORTED_MODULE_6__shared_services_admin_admin_service__["a" /* AdminService */], __WEBPACK_IMPORTED_MODULE_4__angular_material__["b" /* MatDialog */], __WEBPACK_IMPORTED_MODULE_1__angular_core__["ViewContainerRef"],
            __WEBPACK_IMPORTED_MODULE_3_ng2_toastr__["ToastsManager"]])
    ], UserListComponent);
    return UserListComponent;
}());

function compare(a, b, isAsc) {
    if (a && isNaN(a)) {
        return (a.toLowerCase() < b.toLowerCase() ? -1 : 1) * (isAsc ? 1 : -1);
    }
    else {
        return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
    }
}
var UniversityConfirmation = (function () {
    function UniversityConfirmation(dialogRef, data, router, adminService, dialog) {
        this.dialogRef = dialogRef;
        this.data = data;
        this.router = router;
        this.adminService = adminService;
        this.dialog = dialog;
    }
    UniversityConfirmation.prototype.onYesClick = function () {
        this.dialogRef.close('yes');
        // this.homePage.onDelete(this.data.admin)
    };
    UniversityConfirmation.prototype.onNoClick = function () {
        this.dialogRef.close();
    };
    UniversityConfirmation = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_1__angular_core__["Component"])({
            selector: 'cities-confirmation-dialog',
            template: __webpack_require__("../../../../../src/app/layout/user-list/confirmation.html"),
            animations: [Object(__WEBPACK_IMPORTED_MODULE_5__router_animations__["a" /* routerTransition */])()]
        }),
        __param(1, Object(__WEBPACK_IMPORTED_MODULE_1__angular_core__["Inject"])(__WEBPACK_IMPORTED_MODULE_4__angular_material__["a" /* MAT_DIALOG_DATA */])),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_4__angular_material__["d" /* MatDialogRef */], Object, __WEBPACK_IMPORTED_MODULE_2__angular_router__["c" /* Router */],
            __WEBPACK_IMPORTED_MODULE_6__shared_services_admin_admin_service__["a" /* AdminService */],
            __WEBPACK_IMPORTED_MODULE_4__angular_material__["b" /* MatDialog */]])
    ], UniversityConfirmation);
    return UniversityConfirmation;
}());



/***/ }),

/***/ "../../../../../src/app/layout/user-list/user-list.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserListModule", function() { return UserListModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("../../../common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_forms__ = __webpack_require__("../../../forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__angular_material_sort__ = __webpack_require__("../../../material/esm5/sort.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_ngx_pagination__ = __webpack_require__("../../../../ngx-pagination/dist/ngx-pagination.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__angular_material__ = __webpack_require__("../../../material/esm5/material.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_ng2_toastr_ng2_toastr__ = __webpack_require__("../../../../ng2-toastr/ng2-toastr.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_ng2_toastr_ng2_toastr___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_6_ng2_toastr_ng2_toastr__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__shared__ = __webpack_require__("../../../../../src/app/shared/index.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__shared_services_admin_admin_service__ = __webpack_require__("../../../../../src/app/shared/services/admin/admin.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__user_list_routing_module__ = __webpack_require__("../../../../../src/app/layout/user-list/user-list-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__user_list_component__ = __webpack_require__("../../../../../src/app/layout/user-list/user-list.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};











var UserListModule = (function () {
    function UserListModule() {
    }
    UserListModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_9__user_list_routing_module__["a" /* UserListRoutingModule */],
                __WEBPACK_IMPORTED_MODULE_7__shared__["b" /* PageHeaderModule */],
                __WEBPACK_IMPORTED_MODULE_2__angular_forms__["i" /* ReactiveFormsModule */],
                __WEBPACK_IMPORTED_MODULE_2__angular_forms__["d" /* FormsModule */],
                __WEBPACK_IMPORTED_MODULE_3__angular_material_sort__["a" /* MatSortModule */],
                __WEBPACK_IMPORTED_MODULE_4_ngx_pagination__["a" /* NgxPaginationModule */],
                __WEBPACK_IMPORTED_MODULE_5__angular_material__["f" /* MatPaginatorModule */],
                __WEBPACK_IMPORTED_MODULE_5__angular_material__["c" /* MatDialogModule */],
                __WEBPACK_IMPORTED_MODULE_6_ng2_toastr_ng2_toastr__["ToastModule"].forRoot(),
            ],
            declarations: [__WEBPACK_IMPORTED_MODULE_10__user_list_component__["b" /* UserListComponent */], __WEBPACK_IMPORTED_MODULE_10__user_list_component__["a" /* UniversityConfirmation */]],
            providers: [__WEBPACK_IMPORTED_MODULE_8__shared_services_admin_admin_service__["a" /* AdminService */]],
            entryComponents: [__WEBPACK_IMPORTED_MODULE_10__user_list_component__["a" /* UniversityConfirmation */]]
        })
    ], UserListModule);
    return UserListModule;
}());



/***/ })

});
//# sourceMappingURL=user-list.module.chunk.js.map