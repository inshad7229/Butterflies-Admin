webpackJsonp(["countries.module"],{

/***/ "../../../../../src/app/layout/countries/confirmation.html":
/***/ (function(module, exports) {

module.exports = "<div class=\"modal-header\">\r\n\t<h4 class=\"modal-title\" >Hey!! <span class=\"pull-right\"><a (click)=\"onNoClick()\"><i class=\"fa fa-times\"></i></a></span> </h4>\r\n</div>\r\n<div class=\"modal-body\">\r\n\t<div >\r\n\t\t<p >Are you sure you want to delete this Country? </p>\r\n\t</div>\r\n\t<div  >\r\n\t\t<button class=\"btn btn-round btn-mat btn-disabled btn-success\" style=\"width: 48%\" (click)=\"onYesClick()\">Yes</button>\r\n\t\t<button class=\"btn btn-round btn-mat btn-disabled btn-danger\" style=\"width: 48%\" (click)=\"onNoClick()\">No Thanks</button>\r\n\t</div>\r\n</div>"

/***/ }),

/***/ "../../../../../src/app/layout/countries/countries-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CountriesRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__countries_component__ = __webpack_require__("../../../../../src/app/layout/countries/countries.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var routes = [
    {
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_2__countries_component__["a" /* CountriesComponent */]
    }
];
var CountriesRoutingModule = (function () {
    function CountriesRoutingModule() {
    }
    CountriesRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["d" /* RouterModule */].forChild(routes)],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["d" /* RouterModule */]]
        })
    ], CountriesRoutingModule);
    return CountriesRoutingModule;
}());



/***/ }),

/***/ "../../../../../src/app/layout/countries/countries.component.html":
/***/ (function(module, exports) {

module.exports = "<div [@routerTransition]>\n    <app-page-header [heading]=\"'Cities'\" [icon]=\"'fa-edit'\"></app-page-header>\n    <div class=\"row\">\n        <div class=\"col-lg-12\">\n            <form role=\"form\" [formGroup]=\"verifiactionForm\">\n                <div class=\"form-group has-success\">\n                    <label class=\"form-control-label\" for=\"inputSuccess\">Country Name</label>\n                    <input type=\"text\" class=\"form-control form-control-success\" id=\"inputSuccess\" [formControl]=\"verifiactionForm.controls['countryName']\" [(ngModel)]=\"datamodel.name\">\n                    <p  *ngIf=\"verifiactionForm.controls['countryName'].hasError('required') && verifiactionForm.controls['countryName'].touched\">\n                     Country Name is <strong>required</strong>\n                    </p>\n                    <p  *ngIf=\"verifiactionForm.controls['countryName'].hasError('pattern')\">\n                               Please enter valid City Name !!\n                    </p>\n                    <p  *ngIf=\"verifiactionForm.controls['countryName'].hasError('maxlength')\">\n                               max length is 100\n                    </p>\n                </div>\n                <div class=\"form-group has-success\">\n                    <label class=\"form-control-label\" for=\"inputSuccess\">Country Order</label>\n                    <input type=\"number\" class=\"form-control form-control-success\" id=\"inputSuccess\" [formControl]=\"verifiactionForm.controls['country_order']\" [(ngModel)]=\"datamodel.country_order\">\n                    <p  *ngIf=\"verifiactionForm.controls['country_order'].hasError('required') && verifiactionForm.controls['country_order'].touched\">\n                     Country Order is <strong>required</strong>\n                    </p>\n                    <p  *ngIf=\"verifiactionForm.controls['country_order'].hasError('min')\">\n                               min value is 1\n                    </p>\n                </div>\n                    <button type=\"submit\" class=\"btn btn-secondary\" [disabled]=\"!verifiactionForm.valid\" (click)=\"onSubmit()\">Submit</button>\n                     <button type=\"reset\" class=\"btn btn-secondary\" (click)=\"onReset()\">Reset Button</button>\n            </form>\n        </div>\n    </div>\n    <div class=\"row\">\n        <div class=\"contn-class\">\n                <div class=\"card-header\">Countries List</div>\n                <table class=\"card-body table\" matSort (matSortChange)=\"sortData($event)\" *ngIf=\"sortedData\">\n                    <thead>\n                    <tr>\n                        <th>#</th>\n                        <th  mat-sort-header=\"name\">Country Name</th>\n                        <th  mat-sort-header=\"order\">Order</th>\n                        <th  mat-sort-header=\"status\">Status</th>\n                        <th>Action</th>\n                    </tr>\n                    </thead>\n                    <tbody>\n                    <tr *ngFor=\"let country of sortedData ;let i=index\" class=\"{{getClass(i)}}\">\n                        <th scope=\"row\">{{i+1}}</th>\n                        <td >{{country.name}}</td>\n                        <td >{{country.country_order}}</td>\n                        <td >\n                                 <span class=\"cus-switch\">\n                                    <label class=\"switch m-b-0\">\n                                        <input type=\"checkbox\" [(ngModel)]=\"country.status\" [ngModelOptions]=\"{standalone: true}\" (change)=\"onChange(country)\">\n                                        <span class=\"slider round\"></span>\n                                    </label>\n                                </span>\n                        </td>\n                        <td >\n                            <a  href=\"javascript:void(0)\" (click)=\"onEdit(country)\" class=\"fa fa-pencil-square-o fa-lg user-button\" ></a>\n                            <a  href=\"javascript:void(0)\" (click)=\"opendelete(country)\" class=\"fa fa-trash fa-lg user-button\" ></a>\n                        </td>\n                    </tr>\n                    </tbody>\n                </table>\n            </div>\n                <mat-paginator *ngIf=\"CountyList\" #pager [length]=\"CountyList.length\"\n                                  [pageSize]=\"pageSize\"\n                                  [pageSizeOptions]=\"[5, 10, 25, 100]\" (page)=\"pageoption($event)\">\n                </mat-paginator>\n    </div>\n    <!-- /.row -->\n</div>\n"

/***/ }),

/***/ "../../../../../src/app/layout/countries/countries.component.scss":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../../css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".contn-class {\n  float: left;\n  width: 100%;\n  padding: 20px 15px; }\n", ""]);

// exports


/*** EXPORTS FROM exports-loader ***/
module.exports = module.exports.toString();

/***/ }),

/***/ "../../../../../src/app/layout/countries/countries.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CountriesComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return CountryConfirmation; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_forms__ = __webpack_require__("../../../forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_ng2_toastr__ = __webpack_require__("../../../../ng2-toastr/ng2-toastr.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_ng2_toastr___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_ng2_toastr__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__angular_material__ = __webpack_require__("../../../material/esm5/material.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__router_animations__ = __webpack_require__("../../../../../src/app/router.animations.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__shared_services_admin_admin_service__ = __webpack_require__("../../../../../src/app/shared/services/admin/admin.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};







var CountriesComponent = (function () {
    function CountriesComponent(router, fb, adminService, dialog, vcr, toastr) {
        this.router = router;
        this.fb = fb;
        this.adminService = adminService;
        this.dialog = dialog;
        this.toastr = toastr;
        this.users = [];
        this.listIndex = 1;
        this.listSize = 10;
        this.pageIndex = 0;
        this.pageSize = 1;
        this.pageSizeOptions = [5, 10, 25, 100];
        this.editStatus = false;
        this.toastr.setRootViewContainerRef(vcr);
        this.datamodel = {};
        this.verifiactionForm = fb.group({
            'countryName': [null, __WEBPACK_IMPORTED_MODULE_0__angular_forms__["j" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_0__angular_forms__["j" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_0__angular_forms__["j" /* Validators */].maxLength(100)])],
            'country_order': [null, __WEBPACK_IMPORTED_MODULE_0__angular_forms__["j" /* Validators */].compose([__WEBPACK_IMPORTED_MODULE_0__angular_forms__["j" /* Validators */].required, __WEBPACK_IMPORTED_MODULE_0__angular_forms__["j" /* Validators */].min(1)])],
        });
    }
    CountriesComponent.prototype.setPageSizeOptions = function (setPageSizeOptionsInput) {
        this.pageSizeOptions = setPageSizeOptionsInput.split(',').map(function (str) { return +str; });
    };
    CountriesComponent.prototype.ngOnInit = function () {
        this.onGetList();
    };
    CountriesComponent.prototype.onGetList = function () {
        var _this = this;
        this.adminService.CountriesList()
            .subscribe(function (data) {
            if (data.response) {
                ;
                _this.CountyList = data.result;
                _this.toastr.success('Country List', 'Success', { toastLife: 2000, showCloseButton: true });
                //this.sortedData=data.result 
                if (_this.CountyList.length > 5) {
                    _this.pageSize = 5;
                }
                else {
                    _this.pageSize = _this.CountyList.length;
                }
                for (var i = _this.pageIndex * _this.pageSize; i < (_this.pageIndex * _this.pageSize + _this.pageSize); i++) {
                    _this.users.push(_this.CountyList[i]);
                    _this.sortedData = _this.users.slice();
                }
            }
            else {
                _this.toastr.error(data.message, 'Error', { toastLife: 2000, showCloseButton: true });
            }
        });
    };
    CountriesComponent.prototype.getClass = function (i) {
        if (i % 2 == 0) {
            return 'table-success';
        }
        else {
            return 'table-info';
        }
    };
    CountriesComponent.prototype.sortData = function (sort) {
        var data = this.users.slice();
        if (!sort.active || sort.direction == '') {
            this.sortedData = data;
            return;
        }
        this.sortedData = data.sort(function (a, b) {
            var isAsc = sort.direction == 'asc';
            switch (sort.active) {
                case 'name': return compare(a.name.trim(), b.name.trim(), isAsc);
                case 'order': return compare(a.country_order, b.country_order, isAsc);
                case 'status': return compare(a.status, b.status, isAsc);
                default: return 0;
            }
        });
    };
    CountriesComponent.prototype.pageoption = function (event) {
        this.pageSize = event.pageSize;
        this.pageIndex = event.pageIndex;
        this.users = [];
        for (var i = this.pageIndex * this.pageSize; i < (this.pageIndex * this.pageSize + this.pageSize); i++) {
            if (i == this.CountyList.length) {
                break;
            }
            else {
                this.users.push(this.CountyList[i]);
                this.sortedData = this.users.slice();
            }
        }
    };
    CountriesComponent.prototype.onEdit = function (country) {
        this.datamodel = Object.assign({}, country);
    };
    CountriesComponent.prototype.onReset = function () {
        this.datamodel = {};
    };
    CountriesComponent.prototype.onSubmit = function () {
        var _this = this;
        console.log(this.datamodel);
        if (this.datamodel.id) {
            this.adminService.oneditCountry(this.datamodel)
                .subscribe(function (data) {
                if (data.response) {
                    ;
                    var index = _this.CountyList.map(function (img) { return img.id; }).indexOf(_this.datamodel.id);
                    _this.toastr.success('Country Edited', 'Success', { toastLife: 2000, showCloseButton: true });
                    //this.ngOnInit()
                    _this.CountyList[index].name = _this.datamodel.name;
                    if (_this.CountyList.length > 5) {
                        _this.pageSize = 5;
                    }
                    else {
                        _this.pageSize = _this.CountyList.length;
                    }
                    for (var i = _this.pageIndex * _this.pageSize; i < (_this.pageIndex * _this.pageSize + _this.pageSize); i++) {
                        _this.users.push(_this.CountyList[i]);
                        _this.sortedData = _this.users.slice();
                    }
                }
                else {
                    _this.toastr.error(data.message, 'Error', { toastLife: 2000, showCloseButton: true });
                }
            });
        }
        else {
            this.adminService.onAddCountry(this.datamodel)
                .subscribe(function (data) {
                ;
                if (data.response) {
                    ;
                    // this.ngOnInit()
                    _this.toastr.success('Country Added Successfully', 'Success', { toastLife: 2000, showCloseButton: true });
                }
                else {
                    _this.toastr.error(data.message, 'Error', { toastLife: 2000, showCloseButton: true });
                }
            });
        }
    };
    CountriesComponent.prototype.onChange = function (data) {
        var _this = this;
        this.adminService.oneditCountryStatus(data)
            .subscribe(function (data) {
            if (data.response) {
                ;
                // this.onGetList()
                _this.toastr.success('Country updated Successfully', 'Success', { toastLife: 2000, showCloseButton: true });
            }
            else {
                _this.toastr.error(data.message, 'Error', { toastLife: 2000, showCloseButton: true });
            }
        });
    };
    //this.customersList.map(function (img) { return img.customer_id; }).indexOf(this.appointMents[i].customer_id)==-1
    CountriesComponent.prototype.onDelete = function (id) {
        var _this = this;
        this.adminService.oneDeleteCountry(id)
            .subscribe(function (data) {
            if (data.response) {
                ;
                _this.CountyList = _this.CountyList.filter(function (arg) { return arg.id != id; });
                _this.toastr.success('Country deleted', 'Success', { toastLife: 2000, showCloseButton: true });
                _this.users = [];
                if (_this.CountyList.length > 5) {
                    _this.pageSize = 5;
                }
                else {
                    _this.pageSize = _this.CountyList.length;
                }
                for (var i = _this.pageIndex * _this.pageSize; i < (_this.pageIndex * _this.pageSize + _this.pageSize); i++) {
                    _this.users.push(_this.CountyList[i]);
                    _this.sortedData = _this.users.slice();
                }
            }
            else {
            }
        });
    };
    CountriesComponent.prototype.opendelete = function (data) {
        var _this = this;
        var dialogRef = this.dialog.open(CountryConfirmation, {
            width: '400px',
        });
        dialogRef.afterClosed().subscribe(function (result) {
            if (result) {
                _this.onDelete(data.id);
            }
        });
    };
    CountriesComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_1__angular_core__["Component"])({
            selector: 'app-countries',
            template: __webpack_require__("../../../../../src/app/layout/countries/countries.component.html"),
            styles: [__webpack_require__("../../../../../src/app/layout/countries/countries.component.scss")],
            animations: [Object(__WEBPACK_IMPORTED_MODULE_5__router_animations__["a" /* routerTransition */])()]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_2__angular_router__["c" /* Router */], __WEBPACK_IMPORTED_MODULE_0__angular_forms__["b" /* FormBuilder */], __WEBPACK_IMPORTED_MODULE_6__shared_services_admin_admin_service__["a" /* AdminService */], __WEBPACK_IMPORTED_MODULE_4__angular_material__["b" /* MatDialog */], __WEBPACK_IMPORTED_MODULE_1__angular_core__["ViewContainerRef"],
            __WEBPACK_IMPORTED_MODULE_3_ng2_toastr__["ToastsManager"]])
    ], CountriesComponent);
    return CountriesComponent;
}());

function compare(a, b, isAsc) {
    if (a && isNaN(a)) {
        return (a.toLowerCase() < b.toLowerCase() ? -1 : 1) * (isAsc ? 1 : -1);
    }
    else {
        return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
    }
}
var CountryConfirmation = (function () {
    function CountryConfirmation(dialogRef, data, router, adminService, dialog) {
        this.dialogRef = dialogRef;
        this.data = data;
        this.router = router;
        this.adminService = adminService;
        this.dialog = dialog;
    }
    CountryConfirmation.prototype.onYesClick = function () {
        this.dialogRef.close('yes');
        // this.homePage.onDelete(this.data.admin)
    };
    CountryConfirmation.prototype.onNoClick = function () {
        this.dialogRef.close();
    };
    CountryConfirmation = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_1__angular_core__["Component"])({
            selector: 'admin-confirmation-dialog',
            template: __webpack_require__("../../../../../src/app/layout/countries/confirmation.html"),
            animations: [Object(__WEBPACK_IMPORTED_MODULE_5__router_animations__["a" /* routerTransition */])()]
        }),
        __param(1, Object(__WEBPACK_IMPORTED_MODULE_1__angular_core__["Inject"])(__WEBPACK_IMPORTED_MODULE_4__angular_material__["a" /* MAT_DIALOG_DATA */])),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_4__angular_material__["d" /* MatDialogRef */], Object, __WEBPACK_IMPORTED_MODULE_2__angular_router__["c" /* Router */],
            __WEBPACK_IMPORTED_MODULE_6__shared_services_admin_admin_service__["a" /* AdminService */],
            __WEBPACK_IMPORTED_MODULE_4__angular_material__["b" /* MatDialog */]])
    ], CountryConfirmation);
    return CountryConfirmation;
}());



/***/ }),

/***/ "../../../../../src/app/layout/countries/countries.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CountriesModule", function() { return CountriesModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("../../../common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__angular_forms__ = __webpack_require__("../../../forms/esm5/forms.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__angular_material_sort__ = __webpack_require__("../../../material/esm5/sort.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_ngx_pagination__ = __webpack_require__("../../../../ngx-pagination/dist/ngx-pagination.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__angular_material__ = __webpack_require__("../../../material/esm5/material.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_ng2_toastr_ng2_toastr__ = __webpack_require__("../../../../ng2-toastr/ng2-toastr.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_ng2_toastr_ng2_toastr___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_6_ng2_toastr_ng2_toastr__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__shared_services_admin_admin_service__ = __webpack_require__("../../../../../src/app/shared/services/admin/admin.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__shared__ = __webpack_require__("../../../../../src/app/shared/index.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__countries_routing_module__ = __webpack_require__("../../../../../src/app/layout/countries/countries-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__countries_component__ = __webpack_require__("../../../../../src/app/layout/countries/countries.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};











var CountriesModule = (function () {
    function CountriesModule() {
    }
    CountriesModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"],
                __WEBPACK_IMPORTED_MODULE_9__countries_routing_module__["a" /* CountriesRoutingModule */],
                __WEBPACK_IMPORTED_MODULE_8__shared__["b" /* PageHeaderModule */],
                __WEBPACK_IMPORTED_MODULE_2__angular_forms__["i" /* ReactiveFormsModule */],
                __WEBPACK_IMPORTED_MODULE_2__angular_forms__["d" /* FormsModule */],
                __WEBPACK_IMPORTED_MODULE_3__angular_material_sort__["a" /* MatSortModule */],
                __WEBPACK_IMPORTED_MODULE_4_ngx_pagination__["a" /* NgxPaginationModule */],
                __WEBPACK_IMPORTED_MODULE_5__angular_material__["f" /* MatPaginatorModule */],
                __WEBPACK_IMPORTED_MODULE_5__angular_material__["c" /* MatDialogModule */],
                __WEBPACK_IMPORTED_MODULE_6_ng2_toastr_ng2_toastr__["ToastModule"].forRoot(),
            ],
            declarations: [__WEBPACK_IMPORTED_MODULE_10__countries_component__["a" /* CountriesComponent */], __WEBPACK_IMPORTED_MODULE_10__countries_component__["b" /* CountryConfirmation */]],
            providers: [__WEBPACK_IMPORTED_MODULE_7__shared_services_admin_admin_service__["a" /* AdminService */]],
            entryComponents: [__WEBPACK_IMPORTED_MODULE_10__countries_component__["b" /* CountryConfirmation */]]
        })
    ], CountriesModule);
    return CountriesModule;
}());



/***/ })

});
//# sourceMappingURL=countries.module.chunk.js.map