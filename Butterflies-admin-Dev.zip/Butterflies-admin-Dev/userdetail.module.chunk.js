webpackJsonp(["userdetail.module"],{

/***/ "../../../../../src/app/layout/userdetail/userdetail-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return UserdetailRoutingModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__userdetail_component__ = __webpack_require__("../../../../../src/app/layout/userdetail/userdetail.component.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var routes = [{
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_2__userdetail_component__["a" /* UserdetailComponent */]
    }];
var UserdetailRoutingModule = (function () {
    function UserdetailRoutingModule() {
    }
    UserdetailRoutingModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["d" /* RouterModule */].forChild(routes)],
            exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["d" /* RouterModule */]]
        })
    ], UserdetailRoutingModule);
    return UserdetailRoutingModule;
}());



/***/ }),

/***/ "../../../../../src/app/layout/userdetail/userdetail.component.html":
/***/ (function(module, exports) {

module.exports = "<div [@routerTransition]>\n    <app-page-header [heading]=\"'User-Profile'\" [icon]=\"'fa-table'\"></app-page-header>\n    <div class=\"row\">\n        <div class=\"col col-xl-12 col-lg-12\">\n        <!-- *ngIf=\"page=='userDetailEdit'\"\n*ngIf=\"page=='userDetail'\" -->\n            <div class=\"card mb-3\" >\n                <div class=\"card-header\">\n                    User's Detail\n                </div>\n                <div class=\"card-body table-responsive\">\n                    <div class=\"profile-image\">\n                        <img  width=\"400px\" height=\"400px\" alt=\"no_image.jpg\"\n                        [src]=\"profile_image\" class=\"img-thumbnail-profile\" />\n                  \n                    </div>\n                    <fieldset>\n                        <div class=\"profile-data\">\n                            <div class=\"table-responsive\">\n                                <table class=\"card-body table\" > \n                                    <tbody >\n                                    \t<tr >\n                                            <th style=\"border-right: 2px solid #eee\">Name</th>\n                                            <td>{{userDetail.name}}</td>\n                                        </tr>\n                                        <tr >\n                                            <th style=\"border-right: 2px solid #eee\">Age</th>\n                                            <td>{{userDetail.age}}</td>\n                                        </tr>\n                                        <tr >\n                                            <th style=\"border-right: 2px solid #eee\">Email</th>\n                                            <td>{{userDetail.email}}</td>\n                                        </tr>\n                                        <tr >\n                                            <th style=\"border-right: 2px solid #eee\">Contact</th>\n                                            <td>{{userDetail.contact_no}}</td>\n                                        </tr>\n                                        <tr >\n                                            <th style=\"border-right: 2px solid #eee\">Register For</th>\n                                            <td>{{userDetail.register_for}}</td>\n                                        </tr>\n                                        <tr >\n                                            <th style=\"border-right: 2px solid #eee\">Height</th>\n                                            <td>{{userDetail.height}}</td>\n                                        </tr>\n                                        <tr >\n                                            <th style=\"border-right: 2px solid #eee\">Profession</th>\n                                            <td>{{userDetail.profession}}</td>\n                                        </tr>\n                                        <tr >\n                                            <th style=\"border-right: 2px solid #eee\">Languages</th>\n                                            <td>{{userDetail.language}}</td>\n                                        </tr>\n                                        <tr >\n                                            <th style=\"border-right: 2px solid #eee\">Gender</th>\n                                            <td>{{userDetail.gender}}</td>\n                                        </tr>\n                                        <!-- <tr >\n                                            <th style=\"border-right: 2px solid #eee\">Religion</th>\n                                            <td>{{userDetail.religion}}</td>\n                                        </tr> -->\n                                        <tr >\n                                            <th style=\"border-right: 2px solid #eee\">DOB</th>\n                                            <td>{{userDetail.dob}}</td>\n                                        </tr>\n\n                                        <tr >\n                                            <th style=\"border-right: 2px solid #eee\">User Hobbies</th>\n                                            <td>\n                                            <span *ngFor=\"let hobby of userDetail.userHobbies\">{{hobby.hobbies.name}}, </span> </td>\n                                        </tr>\n\n                                        <tr >\n                                            <th style=\"border-right: 2px solid #eee\">University</th>\n                                            <td>{{userDetail.userUniversities.university_name}}</td>\n                                        </tr>\n\n                                        <tr >\n                                            <th style=\"border-right: 2px solid #eee\">User Cities</th>\n                                            <td>{{userDetail.userCities.city_name}}</td>\n                                        </tr>    \n\n                                        <tr >\n                                            <th style=\"border-right: 2px solid #eee\">Country</th>\n                                            <td>{{userDetail.userCountries.name}}</td>\n                                        </tr>\n\n                                    </tbody>\n                                </table>\n                            </div>\n                        </div>\n                    </fieldset>\n                </div>\n                 <div class=\"profile-image\" *ngFor=\"let image of userDetail.userImage\">\n                        <img  width=\"400px\" height=\"400px\" alt=\"no_image.jpg\"\n                        [src]=\"onImage(image)\" class=\"img-thumbnail-profile\" />\n                  \n                 </div>\n\n                 <video width=\"320\" height=\"240\" controls *ngFor=\"let video of userDetail.userVideo\" >\n\t\t\t\t  <source [src]=\"onvideo(video)\" type=\"video/mp4\">\n\t\t\t\t  Your browser does not support the video tag.\n\t\t\t\t</video>\n\n\n\n\n            <!-- </div>\n            <div class=\"card mb-3\" *ngIf=\"page=='userDetailEdit'\">\n                <div class=\"card-header\">\n                    Edit User\n                </div>\n                <div class=\"card-body table-responsive\">\n                <div class=\"profile-image\">\n                    <img [hidden]=\"nonEditableStatus\" width=\"400px\" height=\"400px\" alt=\"no_image.jpg\" [src]=\"image\" class=\"img-thumbnail-profile\" (click)=\"file.click()\" />\n                    <img [hidden]=\"!nonEditableStatus\" width=\"400px\" height=\"400px\" class=\"img-thumbnail-profile\" [src]=\"image\" alt=\"no_image.jpg\">\n                    <div style=\"display: none;\"><input type=\"file\" accept=\"image/*\" #file id=\"uploadImage\" (change)=\"onUploadImage($event)\"></div>\n                </div>\n                <div class=\"profile-data\">\n                    <form role=\"form\" #profileForm=\"ngForm\" novalidate>\n\n                    <fieldset [disabled]=\"nonEditableStatus\">\n\n                        <div class=\"form-group\">\n                            <label for=\"disabledSelect\">First Name</label>\n                            <input class=\"form-control\" type=\"text\" placeholder=\"First Name\" [disabled]=\"nonEditableStatus\" #first_name=\"ngModel\" name=\"first_name\" [(ngModel)]=\"userData.first_name\" required>\n                        </div>\n                        <p padding style=\"color:#D23839\" [hidden]=\"nonEditableStatus || first_name.valid || !first_name.touched\">First name required</p>\n\n                        <div class=\"form-group\">\n                            <label for=\"disabledSelect\">Last Name</label>\n                            <input class=\"form-control\" type=\"text\" placeholder=\"Last Name\" [disabled]=\"nonEditableStatus\" #last_name=\"ngModel\" name=\"last_name\" [(ngModel)]=\"userData.last_name\" required>\n                        </div>\n                        <p padding style=\"color:#D23839\" [hidden]=\"nonEditableStatus || last_name.valid || !last_name.touched\">Last name required</p>\n\n                        <div class=\"form-group\">\n                            <label for=\"disabledSelect\">User Email</label>\n                            <input class=\"form-control\" type=\"text\" placeholder=\"User Email\" disabled #email=\"ngModel\" name=\"email\" [(ngModel)]=\"userData.email\" pattern=\"^[a-zA-Z0-9]+(\\.[_a-z0-9]+)*@[a-z0-9-]+(\\.[a-z0-9-]+)*(\\.[a-z]{2,15})$\" required>\n                        </div>\n                        <p padding style=\"color:#D23839\" [hidden]=\"nonEditableStatus || email.valid || !email.touched\">Email required</p>\n\n                        <div class=\"form-group\">\n                            <label for=\"disabledSelect\">User Type</label>\n                            <input class=\"form-control\" type=\"text\" placeholder=\"Phone Number\" disabled #user_type=\"ngModel\" name=\"user_type\" [(ngModel)]=\"userData.user_type\" required>\n                        </div>\n                        <p padding style=\"color:#D23839\" [hidden]=\"nonEditableStatus || phone_no.valid || !phone_no.touched\">Email required</p>\n\n                        <div class=\"form-group\">\n                            <label for=\"disabledSelect\">Phone Number</label>\n                            <input class=\"form-control\" type=\"text\" placeholder=\"Phone Number\" [disabled]=\"nonEditableStatus\" #phone_no=\"ngModel\" name=\"phone_no\" [(ngModel)]=\"userData.phone_no\" required>\n                        </div>\n                        <p padding style=\"color:#D23839\" [hidden]=\"nonEditableStatus || phone_no.valid || !phone_no.touched\">Email required</p>\n\n                        <div class=\"form-group\">\n                            <label for=\"disabledSelect\">Address</label>\n                            <input class=\"form-control\" type=\"text\" placeholder=\"Address\" [disabled]=\"nonEditableStatus\" #address=\"ngModel\" name=\"address\" [(ngModel)]=\"userData.address\" required>\n                        </div>\n                        <p padding style=\"color:#D23839\" [hidden]=\"nonEditableStatus || address.valid || !address.touched\">Email required</p>\n                    </fieldset>\n                        <button *ngIf=\"nonEditableStatus\" type=\"submit\" class=\"profile-page-button btn btn-primary\" layout-align=\"center end\" (click)=\"onEdit()\">Edit</button>\n                        <button *ngIf=\"!nonEditableStatus\" type=\"submit\" class=\"profile-page-button btn btn-primary\" (click)=\"submit()\" [disabled]=\"profileForm.form.invalid\">Submit</button>\n\n                </form>\n                </div>\n                </div>\n            </div> -->\n        </div>\n    </div>\n</div>\n"

/***/ }),

/***/ "../../../../../src/app/layout/userdetail/userdetail.component.scss":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../../css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "", ""]);

// exports


/*** EXPORTS FROM exports-loader ***/
module.exports = module.exports.toString();

/***/ }),

/***/ "../../../../../src/app/layout/userdetail/userdetail.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return UserdetailComponent; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/esm5/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__shared_services_admin_admin_service__ = __webpack_require__("../../../../../src/app/shared/services/admin/admin.service.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__env__ = __webpack_require__("../../../../../src/app/env.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var UserdetailComponent = (function () {
    function UserdetailComponent(adminService, router, route) {
        var _this = this;
        this.adminService = adminService;
        this.router = router;
        this.route = route;
        this.route.params.subscribe(function (res) {
            console.log(res.id);
            _this.id = res.id;
        });
    }
    UserdetailComponent.prototype.ngOnInit = function () {
        this.userDetailsAdmin();
        console.log(__WEBPACK_IMPORTED_MODULE_3__env__["a" /* ENV */].imgApi);
        this.imagePath = __WEBPACK_IMPORTED_MODULE_3__env__["a" /* ENV */].imgApi;
    };
    UserdetailComponent.prototype.userDetailsAdmin = function () {
        var _this = this;
        this.adminService.userDetailsAdmin(this.id).subscribe(function (data) {
            _this.userDetail = data.result;
            _this.profile_image = _this.imagePath + "users_profile/" + data.result.profile_image;
            console.log(data);
        }, function (err) {
            console.log(err);
        });
    };
    UserdetailComponent.prototype.onImage = function (data) {
        return this.imagePath + "users_images/" + data.image_url;
    };
    UserdetailComponent.prototype.onvideo = function (data) {
        console.log(data);
        return this.imagePath + "users_videos/" + data.video_url;
    };
    UserdetailComponent = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
            selector: 'app-userdetail',
            template: __webpack_require__("../../../../../src/app/layout/userdetail/userdetail.component.html"),
            styles: [__webpack_require__("../../../../../src/app/layout/userdetail/userdetail.component.scss")]
        }),
        __metadata("design:paramtypes", [__WEBPACK_IMPORTED_MODULE_2__shared_services_admin_admin_service__["a" /* AdminService */], __WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* Router */], __WEBPACK_IMPORTED_MODULE_1__angular_router__["a" /* ActivatedRoute */]])
    ], UserdetailComponent);
    return UserdetailComponent;
}());



/***/ }),

/***/ "../../../../../src/app/layout/userdetail/userdetail.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserdetailModule", function() { return UserdetailModule; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/esm5/core.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("../../../common/esm5/common.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__shared__ = __webpack_require__("../../../../../src/app/shared/index.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__userdetail_routing_module__ = __webpack_require__("../../../../../src/app/layout/userdetail/userdetail-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__userdetail_component__ = __webpack_require__("../../../../../src/app/layout/userdetail/userdetail.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__shared_services_admin_admin_service__ = __webpack_require__("../../../../../src/app/shared/services/admin/admin.service.ts");
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var UserdetailModule = (function () {
    function UserdetailModule() {
    }
    UserdetailModule = __decorate([
        Object(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
            imports: [
                __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"], __WEBPACK_IMPORTED_MODULE_2__shared__["b" /* PageHeaderModule */],
                __WEBPACK_IMPORTED_MODULE_3__userdetail_routing_module__["a" /* UserdetailRoutingModule */]
            ],
            declarations: [__WEBPACK_IMPORTED_MODULE_4__userdetail_component__["a" /* UserdetailComponent */]],
            providers: [__WEBPACK_IMPORTED_MODULE_5__shared_services_admin_admin_service__["a" /* AdminService */]]
        })
    ], UserdetailModule);
    return UserdetailModule;
}());



/***/ })

});
//# sourceMappingURL=userdetail.module.chunk.js.map